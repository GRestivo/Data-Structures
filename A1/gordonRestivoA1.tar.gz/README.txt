PLEASE NOTE!!!!
1. There is no testMain or test code for hand in, I didn't have enough time to implement it
2. The LinkedListAPI source and header file are included with the code but I am using a modified list called carList
3. time arrived doesn't seem to always work
4. Couldn't get the format for the output to work, didn't have enough time!
THANKS!!!

Actual README:


Author: Gordon Restivo
Student #: 0971067
Last date modified: 10/11/2017

This program runs a 4 way stop light simulation. The cars and their necessary information are read in via command
line argument and sorted into 4 seperate lists (One for each direction the cars can approach from). As a car moves 
through the intersection it's times are recorded and printed to stdout. The car is deleted from the list once
progressing through the intersection. The simulation continues until all lists are emptied.
